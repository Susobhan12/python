#This is general calculator
#There are various mathematical function
#Addition
x=3+2
print(x)
x=3*5
x=5-3
print(x)
g=15*2
print(g)
h=35/5
print(h) #this is division
