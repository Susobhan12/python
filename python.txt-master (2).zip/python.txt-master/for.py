num = int(input("Enter a number: "))
i = 0
for i in range(num):
    if (i < num):
     i += 1
    print(i)
    



     





