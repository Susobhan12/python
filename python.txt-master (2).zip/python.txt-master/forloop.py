n = int(input("enter your no:")
sum = 0
for i in range(1,n):
    sum = sum + i
    print(sum)

