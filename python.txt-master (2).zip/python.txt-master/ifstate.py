list=[0,1,2,3,4,5,6,7,8]
for l in list:
    if list[l]==0:
        print("Zero")
    elif list[l]==1:
        print("one")
        continue
    elif list[l]==2:
        print("two")
    elif list[l]==4:
        print("Three")
    
list=[2,3,5,7,8,0,9]
for n in range(7):
    print(n)
for n in range(10):
    if n==6:
        break
    print(n)

def Number(n):
    print(n)
n=input("Enter your text:")

