Number=input("enter your number:")
Name=input("enter your name:")
regno=input("enter your regno:")
name="siva"
name2=name[::-1]
name2
if name==name2:
    print("both are equal")
else:
    print("This is not")

list=[1,2,3,4,5]
list[ :2]
list[1: ]

