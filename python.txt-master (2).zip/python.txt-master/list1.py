list=[1,2,3,4,5,6,7,9]
if list[0]==1:
    print("one")
